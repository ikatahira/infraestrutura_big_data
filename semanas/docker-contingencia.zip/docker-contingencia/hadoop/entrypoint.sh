#!/bin/bash
set -e

service ssh start

# jps deve listar NameNode, DataNode, SecondaryNameNode — igual à Semana 05
$HADOOP_HOME/sbin/start-dfs.sh

echo ""
echo "============================================================"
echo " Hadoop pseudo-distribuído no ar!"
echo " Interface web do NameNode: http://localhost:9870"
echo " Para entrar no container:  docker exec -it bigdata-hadoop bash"
echo " Comandos HDFS de exemplo:"
echo "   hdfs dfs -mkdir -p /user/hadoop/dados"
echo "   hdfs dfs -put /dados/vendas.csv /user/hadoop/dados/"
echo "   hdfs dfs -ls /user/hadoop/dados/"
echo "============================================================"
echo ""

tail -f /dev/null
