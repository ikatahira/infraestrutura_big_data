# Ambiente de Contingência — Infraestrutura para Big Data (IAL008)

Este pacote sobe, em containers Docker, os 4 serviços que os alunos instalam manualmente ao longo do semestre: **Hadoop** (Semana 05), **Kafka** (Semana 11), **MongoDB** (Semana 10) e **Spark/Jupyter** (Semanas 07, 08 e 18).

**Objetivo**: ser o "plano B" recomendado no relatório de auditoria — se a instalação manual de um aluno falhar em sala (erro de ambiente, VM sem recursos, Wi-Fi caindo no meio do download etc.), ele usa este ambiente pronto para não perder a aula, e volta a tentar a instalação manual depois, em casa, com calma.

> ⚠️ **Isto não substitui a instalação manual como conteúdo didático.** O objetivo da Semana 05, por exemplo, é o aluno *aprender fazendo* a instalação passo a passo. Este ambiente é só para destravar a aula quando isso não for possível no momento.

## Pré-requisitos

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) instalado e rodando (Windows, Mac ou Linux)
- ~4 GB de espaço livre em disco (as imagens somam esse tanto)
- Conexão com a internet **na primeira vez** (para baixar as imagens e o Hadoop)

## Como usar

```bash
# Na pasta docker-contingencia/
docker compose up -d
```

Na primeira execução, isso vai demorar alguns minutos (baixa as imagens do Kafka/MongoDB/Spark e compila a imagem do Hadoop). Da segunda vez em diante, sobe em segundos.

Para verificar se todos os serviços estão de pé:

```bash
docker compose ps
```

Para parar tudo (sem apagar os dados):

```bash
docker compose stop
```

Para desligar e apagar tudo, inclusive os dados salvos:

```bash
docker compose down -v
```

## Serviços disponíveis

| Serviço | Semana que substitui | Como acessar |
|---|---|---|
| **Hadoop HDFS** | Semana 05 | Interface web: http://localhost:9870 · Terminal: `docker exec -it bigdata-hadoop bash` |
| **Kafka** (modo KRaft, sem ZooKeeper) | Semana 11 | Broker em `localhost:9092` · Terminal: `docker exec -it bigdata-kafka bash` |
| **MongoDB** | Semana 10 | `mongodb://localhost:27017` · Terminal: `docker exec -it bigdata-mongo mongosh` |
| **Spark + Jupyter (PySpark)** | Semanas 07, 08, 18 | http://localhost:8888 (token: `bigdata`) |

Os arquivos `vendas.csv` e `produtos.json` (os mesmos da Semana 01) já estão disponíveis dentro dos containers em `/dados` (Hadoop) e `/home/jovyan/dados` (Spark/Jupyter).

## Comandos de exemplo por semana

### Semana 05 — HDFS
```bash
docker exec -it bigdata-hadoop bash
hdfs dfs -mkdir -p /user/hadoop/dados
hdfs dfs -put /dados/vendas.csv /user/hadoop/dados/
hdfs dfs -ls /user/hadoop/dados/
hdfs dfs -cat /user/hadoop/dados/vendas.csv
```

### Semana 11 — Kafka
```bash
docker exec -it bigdata-kafka bash
# criar o tópico
kafka-topics.sh --create --topic cliques --bootstrap-server localhost:9092
# producer (num terminal)
kafka-console-producer.sh --topic cliques --bootstrap-server localhost:9092
# consumer (em outro terminal / outra aba)
kafka-console-consumer.sh --topic cliques --bootstrap-server localhost:9092 --from-beginning
```

### Semana 10 — MongoDB
```bash
docker exec -it bigdata-mongo mongosh
use bigdata
db.vendas.insertOne({produto: "Notebook", categoria: "Eletrônicos", preco: 3500.00})
db.vendas.find()
```

### Semanas 07/08/18 — Spark
Abra http://localhost:8888 (token `bigdata`), crie um notebook novo e rode:
```python
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Teste").getOrCreate()
df = spark.read.csv("dados/vendas.csv", header=True, inferSchema=True)
df.show()
```

## Solução de problemas

- **Porta já em uso** (ex: erro `port is already allocated`): outro programa já está usando a porta 9870, 9092, 27017 ou 8888. Feche o outro programa ou edite o `docker-compose.yml` trocando a porta da esquerda (ex: `"9871:9870"`).
- **`docker compose up` falha ao construir o Hadoop**: normalmente é falta de internet no momento do build (ele baixa o Hadoop 3.3.6 da Apache). Tente de novo.
- **Container do Hadoop sobe mas a interface web não abre**: espere ~15-20 segundos após o `docker compose up` — o HDFS leva um tempinho para inicializar os serviços internos.
- **Windows**: recomenda-se rodar com o WSL2 integrado ao Docker Desktop (configuração padrão), para melhor desempenho.

## O que este ambiente NÃO cobre

- AWS/EMR (Semanas 13-14) — depende de conta AWS real, não dá para "containerizar" a nuvem
- ESP32/IoT (Semana 15) — depende de hardware físico
- Ferramentas de BI como Power BI (Semana 17) — normalmente já é web-based, não costuma falhar por instalação

Para essas semanas, o "plano B" precisa ser outro (ex: um vídeo gravado de demonstração, como já sugerido para a Semana 20).
